# db/config.py
import os
from app.settings import load_settings

_SETTINGS = load_settings()
_db = (_SETTINGS.get("db") or {})

def _as_bool(v, default=False) -> bool:
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in {"1", "true", "yes", "y", "on"}

DB_CONFIG = {
    "server": os.getenv("OCR_DB_SERVER", _db.get("server", "localhost")),
    "database": os.getenv("OCR_DB_DATABASE", _db.get("database", "")),
    "trusted_connection": _as_bool(os.getenv("OCR_DB_TRUSTED", _db.get("trusted_connection", True)), True),
    "username": os.getenv("OCR_DB_USER", _db.get("username", "")),
    "password": os.getenv("OCR_DB_PASSWORD", _db.get("password", "")),
    "driver": os.getenv("OCR_DB_DRIVER", _db.get("driver", "ODBC Driver 17 for SQL Server")),
}