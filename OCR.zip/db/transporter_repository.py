# db/transporter_repository.py

from db.repository import BaseRepository


class TransporterRepository(BaseRepository):

    def find_transporter_by_bank(self, iban: str, bic: str):
        query = """
            SELECT 
                bank.IBAN,
                bank.SWIFT,
                bank.BankName,
                kun.name1,
                kun.Strasse,
                kun.Ort,
                kun.LKZ,
                kun.PLZ,
                kun.UstId,
                bank.KundenNr
            FROM xxakunbank bank
            LEFT JOIN xxakun kun 
                ON kun.KundenNr = bank.KundenNr
            WHERE REPLACE(UPPER(bank.IBAN), ' ', '') = REPLACE(UPPER(?), ' ', '')
            AND REPLACE(UPPER(bank.SWIFT), ' ', '') = REPLACE(UPPER(?), ' ', '')
        """


        result = self.fetch_one(query, (iban, bic))       


        return result

    def search_transporters_by_name(self, name_part: str):
        name_part = (name_part or "").strip()
        if not name_part:
            return []

        query = """
            SELECT TOP 10
                kundennr,
                name1
            FROM xxakun
            WHERE
                GsDruck = 'J'
                AND (
                    UPPER(name1) LIKE UPPER(?)
                    OR UPPER(CAST(kundennr AS VARCHAR(50))) LIKE UPPER(?)
                )
            ORDER BY name1
        """

        like = f"%{name_part}%"
        return self.fetch_all(query, (like, like))
    
    def get_bank_by_kundennr(self, kundennr: str):
        query = """
            SELECT IBAN, SWIFT
            FROM xxakunbank
            WHERE KundenNr = ?
        """
        return self.fetch_one(query, (kundennr,))


    def update_bank(self, kundennr: str, iban: str, bic: str):
        # Vérifier si ligne existe
        check_query = """
            SELECT COUNT(*) AS cnt
            FROM xxakunbank
            WHERE KundenNr = ?
        """

        result = self.fetch_one(check_query, (kundennr,))
        exists = result and result.get("cnt", 0) > 0

        if exists:
            query = """
                UPDATE xxakunbank
                SET IBAN = ?, SWIFT = ?, LfdNr = 1  
                WHERE KundenNr = ?
            """
            self.execute(query, (iban, bic, kundennr))
            print("UPDATE effectué")

        else:
            query = """
                INSERT INTO xxakunbank (KundenNr, IBAN, SWIFT, LfdNr)
                VALUES (?, ?, ?,1)
            """
            self.execute(query, (kundennr, iban, bic))
            print("INSERT effectué")



    def find_transporter_by_kundennr(self, kundennr: str):
        query = """
            SELECT TOP 1
                bank.IBAN,
                bank.SWIFT,
                bank.BankName,
                kun.name1,
                kun.Strasse,
                KUN.PLZ,
                kun.Ort,
                kun.LKZ,
                kun.KundenNr
            FROM xxakun kun
            LEFT JOIN xxakunbank bank
                ON bank.KundenNr = kun.KundenNr
            WHERE kun.KundenNr = ?
            ORDER BY bank.LfdNr
        """
        return self.fetch_one(query, (kundennr,))

    def get_ustid_by_kundennr(self, kundennr: str):
        query = """
            SELECT UstId
            FROM XXAKun
            WHERE KundenNr = ?
        """
        return self.fetch_one(query, (kundennr,))

    def get_ktoKreA_by_kundennr(self, kundennr: str):
        query = """
            SELECT KtoKreA
            FROM XXAKun
            WHERE KundenNr = ?
        """
        return self.fetch_one(query, (kundennr,))


    def update_ktoKreA(self, kundennr: str, konto_aux: str):
        query = """
            UPDATE XXAKun
            SET KtoKreA = ?, KtoKre = 4
            WHERE KundenNr = ?
        """
        self.execute(query, (konto_aux, kundennr))


