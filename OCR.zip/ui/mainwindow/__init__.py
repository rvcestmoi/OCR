"""Refactored MainWindow building blocks."""
